import React from 'react';

/* components */
import { Home } from '../../components/Home';

export const HomeContainer = () =>
    <section>
        <Home />
    </section>;
